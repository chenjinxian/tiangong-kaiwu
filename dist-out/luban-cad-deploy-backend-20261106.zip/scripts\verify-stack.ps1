﻿# ============================================================
# verify-stack.ps1 — 天工开物统一栈（根 docker-compose.yml）验收脚本
#
# 全栈一键验收：health 探针 → 服务账号登录 → iTwin/iModel/baseline 数据链
# → WS cookie 握手 → 原生库 dev-build 横幅 → web 镜像陈旧检测 → 汇总表 + 退出码。
#
# 用法:
#   powershell -File scripts/verify-stack.ps1                    # 全量（含 baseline 数据链，最慢 ~5min）
#   powershell -File scripts/verify-stack.ps1 -SkipBaseline      # 跳过数据链（health + WS + 横幅）
#   powershell -File scripts/verify-stack.ps1 -BaseUrl http://localhost:5301
#
# 前置:
#   1) 仓库根 .env（scripts/generate-env.ps1；登录用 IMODELHUB_ADMIN_EMAIL/PASSWORD）
#   2) 栈已起：docker compose up -d + powershell -File scripts/start-ms-host.ps1 -Detach
#
# 探针表（实配依据，改路由时同步此表）:
#   HUB      GET http://<host>:5400/health        直探 —— deploy/default.conf.template 无 /health 路由，
#                                                 经 BaseUrl 探 /health 只会落进 web SPA 兜底
#   MS       GET http://<host>:5401/health        宿主进程（或 --profile container 映射口），main.ts:243
#   web      GET <BaseUrl>/（默认 :5301）          经 nginx → web:3000（栈内）静态
#   WA       GET http://<host>:5402/health        webhook-server.ts /health（WA 无 /health/live；
#                                                 根 compose healthcheck 同款端点），不经 nginx
#   azurite  GET http://<host>:10500/             任意 HTTP 应答即视为 up（含 400/403）
#
# 数据链（-SkipBaseline 跳过；请求形状对照 imodelhub-services DTO）:
#   POST /auth/email/login {email,password}          → {token, refreshToken, tokenExpires, user}
#   POST /itwins            {displayName,subClass}   → {iTwin:{id}}        （CreateiTwinDto 必填仅 displayName；class 由 subClass 派生）
#   POST /imodels           {iTwinId,name}           → {iModel:{id,state}} （creationMode 缺省 empty → HUB 发
#                                                       IMODEL_CREATED(needBaseline)；漏收则 WA recovery checker
#                                                       每 RECOVERY_CHECK_INTERVAL_MINUTES(默认5) 分钟兜底 requeue）
#   GET  /imodels/{id}       轮询 10s × 5min          → iModel.state == 'initialized'（终态 failed/missingFiles 提前失败）
#   DELETE /imodels/{id} + DELETE /itwins/{id}        → 204（best-effort，失败仅告警不扣退出码）
#
# WS 探针（Step C）: 纯 node 核心模块手工 Upgrade 握手 —— Node 全局 WebSocket(undici)
#   是 WHATWG API，无法携带自定义 Cookie 头；这里以 http.request + 'upgrade' 事件发送
#   luban_cad_auth cookie（FE features/auth/services/auth/client.ts storeAuth 同形状），
#   断言 101 + Sec-WebSocket-Accept 正确；负向探针（无 cookie 无 query token）断言被 401 拒。
#
# 横幅核验（Step D）: "using dev build from ..." 由本地编译原生包在加载时打印；
#   宿主 MS 先查 %TEMP%\luban-cad-modeling-server.log(.err)（start-ms-host.ps1 -Detach 重定向），
#   找不到再回退 `docker compose logs modeling-server`（--profile container 形态），报告命中来源。
#
# web 镜像陈旧检测（Step E，B2 2026-10-26）: compose 的 web 是本仓 build（非 GHCR
#   拉取），fetch-backend 的 compose pull 不更新它——镜像可能停在旧源。比对镜像
#   OCI revision 标签（rebuild-web.ps1 注入）与最新 web 源提交 sha，无标签时退化为
#   Created vs 最新 web 源提交时间；陈旧打黄色 WARN 提示 scripts/rebuild-web.ps1，
#   不扣退出码（诚实报告而非硬门，功能是否受损由 A-D 判定）。
#   源范围（W1-I5）：`luban-cad` + `itwinjs-core` 两个整目录——Dockerfile 复制
#   整个 luban-cad/ 并消费其 pnpm-lock.yaml / package.json / pnpm-workspace.yaml /
#   docker-closure.cjs，只盯 apps/web + packages 会漏掉这些构建输入。
# ============================================================
[CmdletBinding()]
param(
    [string]$BaseUrl = 'http://localhost:5301',
    [switch]$SkipBaseline
)

$ErrorActionPreference = 'Stop'
$RepoRoot = Split-Path -Parent $PSScriptRoot
$EnvFile  = Join-Path $RepoRoot '.env'

# --- 规范化 BaseUrl / 探针主机 ---
if ($BaseUrl -notmatch '^https?://') { $BaseUrl = "http://$BaseUrl" }
$Base = $BaseUrl.TrimEnd('/')
$ProbeHost = ([uri]$Base).Host
if (-not $ProbeHost) { $ProbeHost = 'localhost' }
if ($Base -like 'https:*') {
    # PS5.1 默认协议集可能不含 TLS1.2
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
}

# ============================================================
# 输出与结果登记
# ============================================================
$Script:Rows = New-Object System.Collections.Generic.List[object]
$Script:FatalFails = 0
$Script:Warns = 0

function Add-Check {
    # -Warn: 黄色警示行（部署卫生类问题，不扣退出码——诚实报告而非硬门）
    param([string]$Step, [string]$Name, [bool]$Ok, [string]$Detail, [switch]$NonFatal, [switch]$Warn)
    $label = if ($Warn) { 'WARN' } elseif ($Ok) { 'OK' } else { 'FAIL' }
    $Script:Rows.Add([pscustomobject]@{ Step = $Step; Result = $label; Check = $Name; Detail = $Detail })
    $color = if ($Warn) { 'Yellow' } elseif ($Ok) { 'Green' } else { 'Red' }
    Write-Host ("  [{0}] {1}  {2}" -f $label, $Name, $Detail) -ForegroundColor $color
    if ($Warn) { $Script:Warns++ }
    elseif (-not $Ok -and -not $NonFatal) { $Script:FatalFails++ }
}

# ============================================================
# HTTP 探针（PS5.1 兼容：HttpWebRequest 直用，4xx/5xx 不抛进调用方；
#   禁用系统代理与 Expect:100-continue，避免本机代理劫持 localhost 探针）
# ============================================================
function Invoke-StackHttp {
    param(
        [Parameter(Mandatory=$true)][string]$Method,
        [Parameter(Mandatory=$true)][string]$Uri,
        [int]$TimeoutSec = 10,
        [string]$Body,
        [string]$ContentType = 'application/json',
        [hashtable]$Headers = @{}
    )
    $out  = @{ StatusCode = -1; Body = ''; Error = $null }
    $resp = $null
    try {
        $req = [System.Net.HttpWebRequest]::Create($Uri)
        # HTTP 方法大小写敏感（RFC 7231 token）——.NET 不做归一化，'Delete' 原样上线
        # 会被 node 端 llhttp 以 HPE_INVALID_METHOD 拒成 400，这里强制大写
        $req.Method = $Method.ToUpperInvariant()
        $req.Timeout = $TimeoutSec * 1000
        $req.ReadWriteTimeout = $TimeoutSec * 1000
        $req.Proxy = $null
        $req.AllowAutoRedirect = $false
        $req.ServicePoint.Expect100Continue = $false
        foreach ($k in $Headers.Keys) { $req.Headers.Add([string]$k, [string]$Headers[$k]) }
        if ($Body) {
            $req.ContentType = $ContentType
            $buf = [System.Text.Encoding]::UTF8.GetBytes($Body)
            $req.ContentLength = $buf.Length
            $rs = $req.GetRequestStream()
            $rs.Write($buf, 0, $buf.Length)
            $rs.Close()
        }
        try { $resp = $req.GetResponse() }
        catch [System.Net.WebException] {
            if ($_.Exception.Response) { $resp = $_.Exception.Response } else { throw }
        }
        $out.StatusCode = [int]$resp.StatusCode
        try {
            $sr = New-Object System.IO.StreamReader($resp.GetResponseStream(), [System.Text.Encoding]::UTF8)
            $out.Body = $sr.ReadToEnd()
        } catch { }
    } catch {
        # 解开 MethodInvocationException 包装，直接给底层传输错误
        $out.Error = $_.Exception.GetBaseException().Message
    } finally {
        if ($resp) { try { $resp.Close() } catch { } }
    }
    return $out
}

function Convert-JsonSafe([string]$Text) {
    if (-not $Text) { return $null }
    try { return $Text | ConvertFrom-Json } catch { return $null }
}

function Import-DotEnv([string]$Path) {
    $map = @{}
    if (-not (Test-Path $Path)) { return $map }
    foreach ($line in (Get-Content -Path $Path)) {
        $t = $line.Trim()
        if ($t -eq '' -or $t.StartsWith('#')) { continue }
        $i = $t.IndexOf('=')
        if ($i -lt 1) { continue }
        $map[$t.Substring(0, $i).Trim()] = $t.Substring($i + 1).Trim().Trim('"').Trim("'")
    }
    return $map
}

# ============================================================
# 服务账号登录（B/C 共用，至多执行一次；结果含失败也缓存以免重复触发
#   HUB 登录节流 5 次/15 分钟）
# ============================================================
$Script:AuthTried = $false
$Script:Auth = $null    # @{ Token; Refresh; ExpiresAt(ms) }

function Get-ServiceAccountAuth {
    if ($Script:AuthTried) { return $Script:Auth }
    $Script:AuthTried = $true

    $envMap = Import-DotEnv -Path $EnvFile
    $email = $envMap['IMODELHUB_ADMIN_EMAIL']
    $password = $envMap['IMODELHUB_ADMIN_PASSWORD']
    if (-not $email -or -not $password) {
        Add-Check 'B' '服务账号登录' $false "缺 IMODELHUB_ADMIN_EMAIL/PASSWORD（$EnvFile；先跑 scripts/generate-env.ps1）"
        return $null
    }

    $r = Invoke-StackHttp -Method Post -Uri "$Base/auth/email/login" -TimeoutSec 30 `
        -Body ((@{ email = $email; password = $password } | ConvertTo-Json -Compress))
    $json = Convert-JsonSafe $r.Body
    if ($r.StatusCode -eq 200 -and $json -and $json.token) {
        $expiresAt = $json.tokenExpires
        if (-not $expiresAt) { $expiresAt = ([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() + 900 * 1000) }
        $Script:Auth = @{ Token = [string]$json.token; Refresh = [string]$json.refreshToken; ExpiresAt = [long]$expiresAt }
        Add-Check 'B' '服务账号登录' $true "HTTP 200，user=$($json.user.email)（经 $Base/auth → nginx → HUB）"
    } elseif ($r.StatusCode -eq 401) {
        Add-Check 'B' '服务账号登录' $false 'HTTP 401：.env 凭据与 HUB seed 不一致（改 HUB 侧账号或根 .env）'
    } elseif ($r.StatusCode -eq 429) {
        Add-Check 'B' '服务账号登录' $false 'HTTP 429：登录节流（5 次/15 分钟），稍后重试'
    } elseif ($r.Error) {
        Add-Check 'B' '服务账号登录' $false "传输失败：$($r.Error)（HUB health 已 OK 时优先怀疑 nginx /auth 路由）"
    } else {
        Add-Check 'B' '服务账号登录' $false "HTTP $($r.StatusCode)：$($r.Body.Substring(0, [Math]::Min(160, $r.Body.Length)))"
    }
    return $Script:Auth
}

# ============================================================
# Step A —— health 探针
# ============================================================
Write-Host ''
Write-Host "== Step A: health 探针（BaseUrl=$Base，直探主机=$ProbeHost）==" -ForegroundColor Cyan
$msHealthy = $false

$r = Invoke-StackHttp -Method Get -Uri "http://${ProbeHost}:5400/health" -TimeoutSec 5
if ($r.StatusCode -eq 200) {
    Add-Check 'A' 'HUB :5400/health' $true 'HTTP 200（直探：nginx 无 /health 路由）'
} elseif ($r.Error) {
    Add-Check 'A' 'HUB :5400/health' $false "$($r.Error)（docker compose up -d imodelhub）"
} else {
    Add-Check 'A' 'HUB :5400/health' $false "HTTP $($r.StatusCode)（503 = 其依赖 postgres/redis 未就绪）"
}

$r = Invoke-StackHttp -Method Get -Uri "http://${ProbeHost}:5401/health" -TimeoutSec 5
if ($r.StatusCode -eq 200) {
    $msHealthy = $true
    Add-Check 'A' 'MS :5401/health' $true 'HTTP 200（宿主进程或 --profile container 映射口）'
} elseif ($r.Error) {
    Add-Check 'A' 'MS :5401/health' $false "$($r.Error)（宿主形态：scripts/start-ms-host.ps1 -Detach）"
} else {
    Add-Check 'A' 'MS :5401/health' $false "HTTP $($r.StatusCode)"
}

$r = Invoke-StackHttp -Method Get -Uri "$Base/" -TimeoutSec 10
if ($r.StatusCode -eq 200) {
    Add-Check 'A' "web $Base/" $true 'HTTP 200（nginx → web:3000 静态）'
} elseif ($r.Error) {
    Add-Check 'A' "web $Base/" $false "$($r.Error)（nginx 未起或端口不通：docker compose up -d nginx）"
} else {
    Add-Check 'A' "web $Base/" $false "HTTP $($r.StatusCode)（502/504 = nginx 通但 web 容器异常）"
}

$r = Invoke-StackHttp -Method Get -Uri "http://${ProbeHost}:5402/health" -TimeoutSec 5
if ($r.StatusCode -eq 200) {
    $waJson = Convert-JsonSafe $r.Body
    $pending = if ($waJson -and $waJson.stats) { $waJson.stats.pendingForwards } else { '?' }
    Add-Check 'A' 'WA :5402/health' $true "HTTP 200，pendingForwards=$pending（WA 无 /health/live，/health 即活探针）"
} elseif ($r.Error) {
    Add-Check 'A' 'WA :5402/health' $false "$($r.Error)（docker compose up -d webhook-agent）"
} else {
    Add-Check 'A' 'WA :5402/health' $false "HTTP $($r.StatusCode)"
}

$r = Invoke-StackHttp -Method Get -Uri "http://${ProbeHost}:10500/" -TimeoutSec 5
if ($r.StatusCode -ge 100) {
    # Azurite 对未认证根路径应答 400/403 均正常 —— 任意 HTTP 应答即 up
    Add-Check 'A' 'azurite :10500' $true "HTTP $($r.StatusCode)（任意应答即 up）"
} else {
    Add-Check 'A' 'azurite :10500' $false "$($r.Error)（docker compose up -d azurite；HUB/MS 的 briefcase/baseline 都依赖它）"
}

# ============================================================
# Step B —— 数据链：登录 → iTwin → iModel → 轮询 initialized → 清理
# ============================================================
if ($SkipBaseline) {
    Write-Host ''
    Write-Host '== Step B: 数据链（-SkipBaseline 跳过）==' -ForegroundColor Cyan
} else {
    Write-Host ''
    Write-Host '== Step B: 数据链（登录 → iTwin → iModel → baseline 轮询）==' -ForegroundColor Cyan
    $auth = Get-ServiceAccountAuth
    if ($auth) {
        $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
        $authHeaders = @{ Authorization = "Bearer $($auth.Token)" }

        # --- create iTwin（CreateiTwinDto 必填仅 displayName；subClass-only
        #     载荷——class 由 hub 派生 Project → Endeavor；旧 class='Project'
        #     在 P0 taxonomy 后是非法 class 值，新 hub 会 422） ---
        $r = Invoke-StackHttp -Method Post -Uri "$Base/itwins" -TimeoutSec 30 -Headers $authHeaders `
            -Body ((@{ displayName = "verify-stack-$stamp"; subClass = 'Project' } | ConvertTo-Json -Compress))
        $json = Convert-JsonSafe $r.Body
        $itwinId = $null
        if ($r.StatusCode -eq 201 -and $json -and $json.iTwin -and $json.iTwin.id) {
            $itwinId = [string]$json.iTwin.id
            Add-Check 'B' '创建 iTwin' $true "HTTP 201，id=$itwinId"
        } elseif ($r.Error) {
            Add-Check 'B' '创建 iTwin' $false "传输失败：$($r.Error)"
        } else {
            Add-Check 'B' '创建 iTwin' $false "HTTP $($r.StatusCode)：$($r.Body.Substring(0, [Math]::Min(160, $r.Body.Length)))"
        }

        if ($itwinId) {
            # --- create iModel（CreateiModelDto 必填 iTwinId+name；creationMode 缺省 empty） ---
            $r = Invoke-StackHttp -Method Post -Uri "$Base/imodels" -TimeoutSec 30 -Headers $authHeaders `
                -Body ((@{ iTwinId = $itwinId; name = "verify-stack-baseline-$stamp" } | ConvertTo-Json -Compress))
            $json = Convert-JsonSafe $r.Body
            $imodelId = $null
            if ($r.StatusCode -eq 201 -and $json -and $json.iModel -and $json.iModel.id) {
                $imodelId = [string]$json.iModel.id
                $state0 = $json.iModel.state
                Add-Check 'B' '创建 iModel' $true "HTTP 201，id=$imodelId，state=$state0"
            } elseif ($r.Error) {
                Add-Check 'B' '创建 iModel' $false "传输失败：$($r.Error)"
            } else {
                Add-Check 'B' '创建 iModel' $false "HTTP $($r.StatusCode)：$($r.Body.Substring(0, [Math]::Min(160, $r.Body.Length)))"
            }

            if ($imodelId) {
                # --- 轮询 state → initialized（10s × 5min；WA webhook 或 recovery checker 兜底） ---
                $deadlineSec = 300
                $intervalSec = 10
                $attempts = [Math]::Ceiling($deadlineSec / $intervalSec)
                $finalState = $null
                $transportError = $null
                for ($i = 1; $i -le $attempts; $i++) {
                    $r = Invoke-StackHttp -Method Get -Uri "$Base/imodels/$imodelId" -TimeoutSec 15 -Headers $authHeaders
                    $json = Convert-JsonSafe $r.Body
                    $state = $null
                    if ($r.StatusCode -eq 200 -and $json -and $json.iModel) { $state = [string]$json.iModel.state }
                    if (-not $state -and $r.Error) { $transportError = $r.Error }
                    Write-Host ("    poll {0}/{1}: state={2}" -f $i, $attempts, $(if ($state) { $state } else { 'unavailable' })) -ForegroundColor DarkGray
                    if ($state -eq 'initialized' -or $state -eq 'failed' -or $state -eq 'missingFiles') { $finalState = $state; break }
                    if ($i -lt $attempts) { Start-Sleep -Seconds $intervalSec }
                }

                if ($finalState -eq 'initialized') {
                    Add-Check 'B' 'baseline 初始化（state=initialized）' $true "iModel $imodelId 已初始化"
                } elseif ($finalState) {
                    Add-Check 'B' 'baseline 初始化（state=initialized）' $false "终态 $finalState —— docker compose logs webhook-agent；宿主 MS 日志 %TEMP%\luban-cad-modeling-server.log"
                } elseif ($transportError) {
                    Add-Check 'B' 'baseline 初始化（state=initialized）' $false "轮询传输失败：$transportError"
                } else {
                    $detail = "{0} 次轮询（约 {1} 分钟）仍未见 initialized —— docker compose logs webhook-agent；recovery checker 默认 5 分钟一轮（RECOVERY_CHECK_INTERVAL_MINUTES），可稍后重跑本脚本" -f $attempts, $deadlineSec
                    Add-Check 'B' 'baseline 初始化（state=initialized）' $false -Detail $detail
                }

                # --- 清理（best-effort，不扣退出码） ---
                $r = Invoke-StackHttp -Method Delete -Uri "$Base/imodels/$imodelId" -TimeoutSec 30 -Headers $authHeaders
                Add-Check 'B' "清理 iModel $imodelId" ($r.StatusCode -eq 204) "HTTP $($r.StatusCode)（期望 204）" -NonFatal
            }
        }

        if ($itwinId) {
            $r = Invoke-StackHttp -Method Delete -Uri "$Base/itwins/$itwinId" -TimeoutSec 30 -Headers $authHeaders
            Add-Check 'B' "清理 iTwin $itwinId" ($r.StatusCode -eq 204) "HTTP $($r.StatusCode)（期望 204）" -NonFatal
        }
    }
}

# ============================================================
# Step C —— WS cookie 握手（纯 node 核心手工 Upgrade；cookie 形状与
#   FE features/auth/services/auth/client.ts storeAuth 一致）
# ============================================================
Write-Host ''
Write-Host '== Step C: WebSocket cookie 握手 == ' -ForegroundColor Cyan
$wsUrl = ($Base -replace '^http', 'ws') + '/ws'
$nodeCmd = Get-Command node -ErrorAction SilentlyContinue
if (-not $nodeCmd) {
    Add-Check 'C' "WS 握手 $wsUrl" $false 'node 不在 PATH —— WS 探针需要 node（本仓工具链依赖）'
} else {
    # 取登录态（-SkipBaseline 时这里才首次登录；已失败则命中缓存，不重复触发 HUB 节流）
    $null = Get-ServiceAccountAuth
    $probeJs = Join-Path $env:TEMP 'verify-stack-ws-probe.js'
    @'
// verify-stack WS 探针：手工 WebSocket Upgrade 握手（无第三方依赖）。
// 用法: node verify-stack-ws-probe.js <wsUrl> <cookieBase64|-> <upgrade|reject>
// 全局 WebSocket(undici) 是 WHATWG API，无法带自定义 Cookie 头 → 用 http 请求的
// 'upgrade' 事件完成握手，并校验 Sec-WebSocket-Accept = base64(sha1(key + GUID))。
const http = require('http');
const https = require('https');
const crypto = require('crypto');
// 所有失败都走 stdout（WS_* 标记 + 受控退出码），保证父脚本只捕 stdout 就够
process.on('uncaughtException', (e) => { console.log('WS_ERROR ' + (e && e.message ? e.message : e)); process.exit(2); });
// argv: [0]=node [1]=本脚本 [2]=wsUrl [3]=cookieBase64|'-' [4]=upgrade|reject
const wsUrl = process.argv[2];
const cookieB64 = process.argv[3] || '-';
const mode = process.argv[4] || 'upgrade';
try {
  const url = new URL(wsUrl);
  const mod = (url.protocol === 'https:' || url.protocol === 'wss:') ? https : http;
  const key = crypto.randomBytes(16).toString('base64');
  const expectedAccept = crypto.createHash('sha1')
    .update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  const headers = {
    Host: url.host,
    Connection: 'Upgrade',
    Upgrade: 'websocket',
    'Sec-WebSocket-Key': key,
    'Sec-WebSocket-Version': '13',
  };
  if (cookieB64 !== '-') {
    headers.Cookie = Buffer.from(cookieB64, 'base64').toString('utf8');
  }
  const req = mod.request({
    hostname: url.hostname,
    port: url.port || (mod === https ? 443 : 80),
    path: url.pathname + url.search,
    headers,
    timeout: 15000,
  });
  req.on('upgrade', (res, socket) => {
    const acceptOk = res.headers['sec-websocket-accept'] === expectedAccept;
    console.log('WS_UPGRADE status=' + res.statusCode + ' acceptMatch=' + acceptOk);
    socket.destroy();
    process.exit(mode === 'upgrade' ? (res.statusCode === 101 && acceptOk ? 0 : 1) : 1);
  });
  req.on('response', (res) => {
    console.log('WS_REJECTED status=' + res.statusCode);
    const expectedReject = mode === 'reject' && res.statusCode === 401;
    res.resume();
    process.exit(expectedReject ? 0 : 1);
  });
  req.on('timeout', () => { console.log('WS_TIMEOUT'); req.destroy(); process.exit(2); });
  req.on('error', (e) => { console.log('WS_ERROR ' + e.message); process.exit(2); });
  req.end();
} catch (e) {
  console.log('WS_ERROR ' + (e && e.message ? e.message : e));
  process.exit(2);
}
'@ | Set-Content -Path $probeJs -Encoding ASCII

    function Invoke-WsProbe {
        param([string]$CookieBase64, [string]$Mode)
        $out = & node $probeJs $wsUrl $CookieBase64 $Mode
        $code = $LASTEXITCODE
        @{ Code = $code; Text = (($out | ForEach-Object { "$_" }) -join ' ').Trim() }
    }

    if ($Script:Auth) {
        # cookie 载荷与 FE writeAuthCookie 同形状：URI 编码的 JSON tokens
        $nowMs = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
        $expiresIn = [int][Math]::Max(0, [Math]::Floor(($Script:Auth.ExpiresAt - $nowMs) / 1000))
        $payload = @{
            accessToken  = $Script:Auth.Token
            refreshToken = $Script:Auth.Refresh
            expiresIn    = $expiresIn
            expiresAt    = $Script:Auth.ExpiresAt
        } | ConvertTo-Json -Compress
        $cookieB64 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes(
            'luban_cad_auth=' + [uri]::EscapeDataString($payload)))

        $p = Invoke-WsProbe -CookieBase64 $cookieB64 -Mode 'upgrade'
        if ($p.Code -eq 0) {
            Add-Check 'C' "WS 握手 $wsUrl" $true "$($p.Text)（cookie luban_cad_auth，无 query token）"
        } elseif ($p.Code -eq 2) {
            Add-Check 'C' "WS 握手 $wsUrl" $false "$($p.Text)（MS 未起或 nginx /ws Upgrade 透传失效）"
        } else {
            Add-Check 'C' "WS 握手 $wsUrl" $false "$($p.Text)（cookie 握手未通过——看 MS 日志 WebSocket auth 行）"
        }

        # 负向探针：无 cookie 无 query token 必须被 401 拒（验 cookie 认证确实在拦）
        $n = Invoke-WsProbe -CookieBase64 '-' -Mode 'reject'
        if ($n.Code -eq 0) {
            Add-Check 'C' 'WS 无凭证拒绝' $true "$($n.Text)"
        } elseif ($n.Code -eq 2) {
            Add-Check 'C' 'WS 无凭证拒绝' $false "$($n.Text)" -NonFatal
        } else {
            Add-Check 'C' 'WS 无凭证拒绝' $false "$($n.Text) —— 无凭证连接未被拦，cookie/query 认证可能失效"
        }
    } else {
        Add-Check 'C' "WS 握手 $wsUrl" $false '无登录态（见上方登录失败行）——先解决登录再验 WS'
    }
}

# ============================================================
# Step D —— 原生库 dev-build 横幅（宿主日志优先，容器日志回退）
# ============================================================
Write-Host ''
Write-Host '== Step D: 原生库 dev-build 横幅 ==' -ForegroundColor Cyan
$banner = 'using dev build'
$foundIn = $null
$foundLine = $null

if (-not $msHealthy) {
    Add-Check 'D' 'MS dev-build 横幅' $false 'MS 未运行（Step A :5401/health 未通过），无从核验横幅'
} else {
    $hostLog = Join-Path $env:TEMP 'luban-cad-modeling-server.log'
    foreach ($f in @($hostLog, "$hostLog.err")) {
        if (-not $foundIn -and (Test-Path $f)) {
            $m = Select-String -LiteralPath $f -SimpleMatch -Pattern $banner
            if ($m) { $foundIn = "宿主日志 $f"; $foundLine = @($m)[0].Line }
        }
    }
    if (-not $foundIn) {
        $dockerCmd = Get-Command docker -ErrorAction SilentlyContinue
        if ($dockerCmd) {
            Push-Location $RepoRoot
            try { $logs = & docker compose logs --tail 3000 modeling-server } finally { Pop-Location }
            $hits = @($logs) -match [regex]::Escape($banner)
            if ($hits.Count -gt 0) {
                $foundIn = 'docker compose logs modeling-server'
                $foundLine = [string]$hits[0]
            }
        }
    }
    if ($foundIn) {
        $line = "$foundLine".Trim()
        if ($line.Length -gt 120) { $line = $line.Substring(0, 120) + '...' }
        # P2.7 复审：横幅只证明“dev build”，不证明版本/来源。读取产物内 provenance，
        # 把版本/HEAD/fallback 一并报告（缺失只提示，不改变横幅门）。
        $provPath = Join-Path $RepoRoot 'dist-backend\modeling-server\node_modules\@bentley\imodeljs-native\native-provenance.json'
        $provDetail = '；provenance 缺失（旧产物）'
        if (Test-Path $provPath) {
            try {
                $prov = Get-Content -Raw -LiteralPath $provPath | ConvertFrom-Json
                $head = [string]$prov.imodelNativeHead
                $headShort = if ($head.Length -ge 12) { $head.Substring(0, 12) } else { $head }
                $provDetail = "；native=$($prov.nativeVersion) head=$headShort fallback=$($prov.fallbackRequired)"
            } catch {
                $provDetail = '；provenance 读取失败'
            }
        }
        Add-Check 'D' 'MS dev-build 横幅' $true "命中于 $foundIn ：$line$provDetail"
    } else {
        $dockerNote = if (Get-Command docker -ErrorAction SilentlyContinue) { '' } else { '（docker 不在 PATH，容器形态日志未查）' }
        $detail = "宿主日志 %TEMP%\luban-cad-modeling-server.log 与容器日志均无 '$banner' $dockerNote —— 重装 node_modules 后需按私有仓流程重跑本地替换并重启 MS"
        Add-Check 'D' 'MS dev-build 横幅' $false -Detail $detail
    }
}

# ============================================================
# Step E —— web 镜像陈旧检测（B2 2026-10-26；WARN 不扣退出码）
#   compose 的 web 是本仓 build（非 GHCR 拉取），fetch-backend 的 compose
#   pull 不更新它——后端发布后镜像可能停在旧源（当日实证：镜像停 10-23、
#   源已到 10-26；e2e 跑 :5300 vite dev 永远看不见）。判据（标签优先）：
#   1) 镜像 OCI 标签 org.opencontainers.image.revision == 最新 web 源提交 sha → 新鲜
#      （标签是唯一权威证据，不看 Created——buildkit 缓存命中导出的镜像
#      Created 会停在首次构建时刻，拿它比时间必误报，2026-10-26 实测）
#   2) 标签存在但 ≠ HEAD（或为手工 build 的 unknown）→ 陈旧
#   3) 无标签（本检查上线前的旧镜像）→ 退化为时间比较：
#      镜像 Created < 最新 web 源提交（W1-I5：luban-cad + itwinjs-core 整目录，
#      均为镜像构建输入）
#   陈旧只 WARN 提示 rebuild-web.ps1，不阻断验收——镜像陈旧属部署卫生问题，
#   功能是否受损由 A-D 判定。
# ============================================================
Write-Host ''
Write-Host '== Step E: web 镜像陈旧检测 ==' -ForegroundColor Cyan
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    Add-Check 'E' 'web 镜像陈旧检测' $true 'docker 不在 PATH —— 跳过（栈验收不受影响）' -Warn
} else {
    # PS5.1 + $ErrorActionPreference='Stop' 下原生命令的 stderr 会抛
    # NativeCommandError（compose 对缺 .env 的 :? 变量插值报错走的就是
    # stderr）——降压执行并吞掉 stderr，失败一律交给降级分支
    function Get-NativeOut {
        param([scriptblock]$Cmd)
        $eap = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        try {
            $out = @(& $Cmd 2>$null)
            if ($LASTEXITCODE -ne 0) { return @() }
            return ,$out
        } finally { $ErrorActionPreference = $eap }
    }

    # --- 定位镜像：compose 文件钉死 name: tiangong-kaiwu → 镜像 = <name>-web:latest
    #     （tag 恒指向最新一次 build，正是陈旧检测要评的对象）；compose ps 的
    #     IMAGE 列作 fallback——但 containerd image store 下它可能给 sha256 摘要
    #     （按 manifest 摘要 inspect 会 miss），摘要值跳过 ---
    $psImg = [string](@(Get-NativeOut { docker compose ps --format '{{.Image}}' web })[0])
    if ($psImg -like 'sha256:*') { $psImg = '' }
    # 2026-11-06：web 改为公开镜像（ghcr.io/.../luban-web-public）+ 本地 build 双形态；
    # 容器实际镜像优先，随后公开名，最后旧本地 tag 兜底。
    $candidates = @($psImg, 'ghcr.io/chenjinxian/luban-web-public:latest', 'tiangong-kaiwu-web:latest') |
      Where-Object { $_ } | Select-Object -Unique

    # --- 镜像 Created + revision 标签：走 JSON 不走 --format——Go 模板里内嵌双引号
    #     会被 PS5.1 原生参数传递剥掉（实测 "function \"org\" not defined" 坑） ---
    $img = $null
    $imgRefUsed = ''
    foreach ($c in $candidates) {
        $jsonText = (Get-NativeOut { docker image inspect $c }) -join "`n"
        if ($jsonText) {
            try { $img = @((ConvertFrom-Json $jsonText) | Select-Object -First 1)[0] } catch { }
            if ($img) { $imgRefUsed = $c; break }
        }
    }
    if (-not $img) {
        Add-Check 'E' 'web 镜像陈旧检测' $true "镜像 $($candidates -join ' / ') 不存在或读取失败（外部先 docker compose pull web；开发者 build 用 scripts/rebuild-web.ps1）" -Warn
    } else {
        $imgCreated = $null
        # docker 的 Created 带纳秒小数（9 位），.NET 解析上限 7 位——截齐再 Parse
        try { $imgCreated = [DateTimeOffset]::Parse((([string]$img.Created) -replace '\.(\d{7})\d+', '.$1'), [Globalization.CultureInfo]::InvariantCulture) } catch { }
        $imgLabel = [string]$img.Config.Labels.'org.opencontainers.image.revision'
        $imgCreatedText = if ($imgCreated) { $imgCreated.ToLocalTime().ToString('yyyy-MM-dd HH:mm') } else { '?' }

        # --- 源侧：最新 web 源提交 sha + 时间（W1-I5：luban-cad + itwinjs-core
        #     两个整目录——Dockerfile 复制整个 luban-cad/，并消费 pnpm-lock.yaml /
        #     package.json / pnpm-workspace.yaml / docker-closure.cjs；只盯
        #     apps/web + packages 会误判「新鲜」。非 git 检出优雅降级为只报告）。
        #     口径不是仓库 HEAD——docs/scripts 等非 web 提交不应判旧（2026-10-27）---
        $srcLine = [string](@(Get-NativeOut { git -C $RepoRoot log -1 --format='%H|%cI' -- luban-cad itwinjs-core })[0])
        $headSha = ''
        $srcTime = $null
        if ($srcLine -match '^([0-9a-f]{40})\|(.+)$') {
            $headSha = $Matches[1]
            try { $srcTime = [DateTimeOffset]::Parse($Matches[2], [Globalization.CultureInfo]::InvariantCulture) } catch { }
        }
        $srcTimeText = if ($srcTime) { $srcTime.ToLocalTime().ToString('yyyy-MM-dd HH:mm') } else { '?' }
        $labelSha = if ($imgLabel.Length -ge 12) { $imgLabel.Substring(0, 12) } else { $imgLabel }
        $headShort = if ($headSha.Length -ge 12) { $headSha.Substring(0, 12) } else { $headSha }

        if (-not $imgCreated) {
            Add-Check 'E' 'web 镜像陈旧检测' $true "镜像 Created 解析失败：$($img.Created)" -Warn
        } elseif (-not $headSha -or -not $srcTime) {
            Add-Check 'E' 'web 镜像陈旧检测' $true "镜像 $imgRefUsed 构建于 $imgCreatedText（非 git 检出或 git 不可用，仅报告不比较）"
        } elseif ($imgLabel -and $imgLabel -ne 'unknown' -and $imgLabel -eq $headSha) {
            # 标签即源提交钦定证据——不再看 Created：buildkit 缓存命中导出的镜像
            # config Created 会停在首次构建时刻（2026-10-26 实测），拿它比时间会误报
            Add-Check 'E' 'web 镜像陈旧检测' $true "镜像 revision 与最新 web 源提交一致（$headShort，Created $imgCreatedText）"
        } elseif ($imgLabel -and $imgLabel -ne 'unknown') {
            Add-Check 'E' 'web 镜像陈旧检测' $true "镜像 revision $labelSha ≠ 最新 web 源提交 $headShort（构建于 $imgCreatedText，源提交 $srcTimeText）——scripts/rebuild-web.ps1 重建" -Warn
        } elseif ($imgCreated -lt $srcTime) {
            Add-Check 'E' 'web 镜像陈旧检测' $true "镜像构建 $imgCreatedText 早于最新 web 源提交 $srcTimeText（无 revision 标签）——scripts/rebuild-web.ps1 重建" -Warn
        } else {
            Add-Check 'E' 'web 镜像陈旧检测' $true "镜像构建 $imgCreatedText ≥ 最新 web 源提交 $srcTimeText（无 revision 标签，按时间比较）"
        }
    }
}

# ============================================================
# Step F —— hub 镜像陈旧 + dist 挂载遮蔽检测（2026-10-27）
#   10-27 实锤：compose 的 imodelhub 曾带宿主 dist 挂载覆盖
#   /usr/src/app/dist——镜像 ID 是新的、容器实跑 10-25 旧产物，发布内容
#   静默失效。本步两判据：
#   1) 运行容器不得有 Destination=/usr/src/app/dist 的挂载（**FAIL**，
#      属发布内容正确性问题，不是卫生提示）；
#   2) 镜像 OCI revision 标签 == imodelhub-services HEAD（标签优先；
#      unknown/缺失时退化为镜像 Created vs hub HEAD 提交时间）——陈旧
#      只 WARN，提示重发 hub 镜像。
#   hub 仓未检出时只做挂载检查（标签仍可报告）。
# ============================================================
Write-Host ''
Write-Host '== Step F: hub 镜像与挂载检查 ==' -ForegroundColor Cyan
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    Add-Check 'F' 'hub 镜像与挂载检查' $true 'docker 不在 PATH —— 跳过（栈验收不受影响）' -Warn
} else {
    function Get-HubNativeOut {
        param([scriptblock]$Cmd)
        $eap = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        try {
            $out = @(& $Cmd 2>$null)
            if ($LASTEXITCODE -ne 0) { return @() }
            return ,$out
        } finally { $ErrorActionPreference = $eap }
    }

    Push-Location $RepoRoot
    try {
        $hubCid = [string](@(Get-HubNativeOut { docker compose ps -q imodelhub })[0])
    } finally { Pop-Location }

    if (-not $hubCid) {
        Add-Check 'F' 'hub dist 挂载检查' $true 'hub 容器未运行（Step A 已判定）——跳过挂载/陈旧比较' -Warn
    } else {
        $container = $null
        $inspectJson = (Get-HubNativeOut { docker inspect $hubCid }) -join "`n"
        if ($inspectJson) {
            try { $container = @((ConvertFrom-Json $inspectJson) | Select-Object -First 1)[0] } catch { }
        }

        $distMounts = @()
        if ($container) {
            $distMounts = @($container.Mounts | Where-Object { $_.Destination -eq '/usr/src/app/dist' })
        }
        if ($distMounts.Count -gt 0) {
            $mountSrc = ($distMounts | ForEach-Object { $_.Source }) -join '; '
            Add-Check 'F' 'hub dist 挂载检查' $false "容器挂载 $mountSrc → /usr/src/app/dist ——镜像内容被遮蔽；删除 compose 该挂载后 force-recreate"
        } else {
            Add-Check 'F' 'hub dist 挂载检查' $true '无宿主 dist 覆盖挂载（hub 内容来自镜像）'
        }

        $hubRoot = Join-Path (Split-Path -Parent $RepoRoot) 'imodelhub-services'
        $hubHead = ''
        $hubTime = $null
        if (Test-Path (Join-Path $hubRoot '.git')) {
            $hubHead = [string](@(Get-HubNativeOut { git -C $hubRoot rev-parse HEAD })[0])
            $hubLine = [string](@(Get-HubNativeOut { git -C $hubRoot log -1 --format='%H|%cI' })[0])
            if ($hubLine -match '^[0-9a-f]{40}\|(.+)$') {
                try { $hubTime = [DateTimeOffset]::Parse($Matches[1], [Globalization.CultureInfo]::InvariantCulture) } catch { }
            }
        }

        $imgName = 'ghcr.io/chenjinxian/imodelhub-public:latest'
        if ($container -and $container.Config.Image) { $imgName = [string]$container.Config.Image }
        $img = $null
        $imgJson = (Get-HubNativeOut { docker image inspect $imgName }) -join "`n"
        if ($imgJson) {
            try { $img = @((ConvertFrom-Json $imgJson) | Select-Object -First 1)[0] } catch { }
        }

        if (-not $img) {
            Add-Check 'F' 'hub 镜像陈旧检测' $true "镜像 $imgName 读取失败——跳过" -Warn
        } else {
            $imgCreated = $null
            try { $imgCreated = [DateTimeOffset]::Parse((([string]$img.Created) -replace '\.(\d{7})\d+', '.$1'), [Globalization.CultureInfo]::InvariantCulture) } catch { }
            $imgLabel = [string]$img.Config.Labels.'org.opencontainers.image.revision'
            $createdText = if ($imgCreated) { $imgCreated.ToLocalTime().ToString('yyyy-MM-dd HH:mm') } else { '?' }
            $hubShort = if ($hubHead.Length -ge 12) { $hubHead.Substring(0, 12) } else { $hubHead }
            $labelShort = if ($imgLabel.Length -ge 12) { $imgLabel.Substring(0, 12) } else { $imgLabel }

            if (-not (Test-Path (Join-Path $hubRoot '.git'))) {
                Add-Check 'F' 'hub 镜像陈旧检测' $true "hub 仓未检出（$hubRoot）——镜像 $imgName 构建于 $createdText，仅报告" -Warn
            } elseif ($imgLabel -and $imgLabel -ne 'unknown' -and $imgLabel -eq $hubHead) {
                Add-Check 'F' 'hub 镜像陈旧检测' $true "镜像 revision 与 hub HEAD 一致（$hubShort，Created $createdText）"
            } elseif ($imgLabel -and $imgLabel -ne 'unknown') {
                Add-Check 'F' 'hub 镜像陈旧检测' $true "镜像 revision $labelShort ≠ hub HEAD $hubShort（Created $createdText，源提交 $(if ($hubTime) { $hubTime.ToLocalTime().ToString('yyyy-MM-dd HH:mm') } else { '?' })）——重发 hub 镜像" -Warn
            } elseif ($imgCreated -and $hubTime -and $imgCreated -lt $hubTime) {
                Add-Check 'F' 'hub 镜像陈旧检测' $true "镜像构建 $createdText 早于 hub HEAD 提交 $($hubTime.ToLocalTime().ToString('yyyy-MM-dd HH:mm'))（无 revision 标签）——重发 hub 镜像" -Warn
            } elseif ($imgCreated -and $hubTime) {
                Add-Check 'F' 'hub 镜像陈旧检测' $true "镜像构建 $createdText ≥ hub HEAD 提交（无 revision 标签，按时间比较）"
            } else {
                Add-Check 'F' 'hub 镜像陈旧检测' $true "镜像 $imgName 无可用 revision/时间信息——仅报告" -Warn
            }
        }
    }
}

# ============================================================
# 汇总 + 退出码
# ============================================================
Write-Host ''
Write-Host '=== verify-stack 汇总 ===' -ForegroundColor Cyan
$display = $Script:Rows | ForEach-Object {
    $d = $_.Detail
    if ($d.Length -gt 88) { $d = $d.Substring(0, 88) + '...' }
    [pscustomobject]@{ Step = $_.Step; Result = $_.Result; Check = $_.Check; Detail = $d }
}
$display | Format-Table -AutoSize | Out-String -Width 200 | ForEach-Object { Write-Host $_ }

$okCount = @($Script:Rows | Where-Object { $_.Result -eq 'OK' }).Count
$warnCount = @($Script:Rows | Where-Object { $_.Result -eq 'WARN' }).Count
$total = $Script:Rows.Count
if ($Script:FatalFails -gt 0) {
    Write-Host ("结果: {0}/{1} 项通过，{2} 项致命失败 → 退出码 1" -f $okCount, $total, $Script:FatalFails) -ForegroundColor Red
    exit 1
}
if ($warnCount -gt 0) {
    Write-Host ("结果: {0}/{1} 项通过，{2} 项警告（部署卫生提示，不扣退出码）→ 退出码 0" -f $okCount, $total, $warnCount) -ForegroundColor Yellow
    exit 0
}
Write-Host ("结果: {0}/{1} 项全部通过 → 退出码 0" -f $okCount, $total) -ForegroundColor Green
exit 0
