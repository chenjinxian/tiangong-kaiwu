﻿# 鲁班CAD 本地部署包（backend-20261106）

不需要克隆源码仓，不需要 GitHub 账号，不需要 docker login。

## 前置

- Windows 10/11 x64
- Docker Desktop（已启动，WSL2 后端）
- Node.js 20.12+（推荐 22 LTS）
- 内存 >= 8 GB，磁盘 >= 8 GB

## 一键启动

在解压后的本目录执行：

`powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/quickstart.ps1
`

脚本会：生成随机密钥 .env -> 匿名下载 modeling-server 产物（支持断点续传）
-> 拉取 4 个公开镜像（web / bff / imodelhub / webhook-agent）
-> 启动容器栈与宿主 modeling-server -> 全栈验收 -> 打开 http://localhost:5301。

注册任意邮箱即可体验。HUB 管理员账号在 .env 的
IMODELHUB_ADMIN_EMAIL / IMODELHUB_ADMIN_PASSWORD。

## 需要获取的完整服务

| 服务 | 来源 | 认证 |
|---|---|---|
| web | GHCR ghcr.io/chenjinxian/luban-web-public:latest | 无 |
| bff | GHCR ghcr.io/chenjinxian/luban-bff-public:latest | 无 |
| imodelhub | GHCR ghcr.io/chenjinxian/imodelhub-public:latest | 无 |
| webhook-agent | GHCR ghcr.io/chenjinxian/luban-webhook-agent-public:latest | 无 |
| modeling-server | GitHub Releases modeling-server-win-x64-*.tgz | 无 |
| postgres / redis / maildev / azurite / nginx | Docker Hub / MCR 官方镜像 | 无 |

宿主只需 Node.js；native/slvs/ACIS 均随 modeling-server 产物分发。
当前仅支持 Windows（modeling-server 是 Windows 原生宿主进程）。

## 常用命令

`powershell
powershell -NoProfile -File scripts/verify-public-deps.ps1   # 公开依赖完整性
powershell -NoProfile -File scripts/verify-stack.ps1        # 全栈验收
docker compose down                                          # 停止容器栈
powershell -NoProfile -File scripts/stop-ms-host.ps1         # 停止宿主后端
`

完整说明与故障排除见 docs/Deployment-Guide.md，或
https://github.com/chenjinxian/tiangong-kaiwu
